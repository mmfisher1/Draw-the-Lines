DRAW THE LINES: MERRITT 2031

Publish free using GitHub Pages:
1. Create a public repository at github.com called draw-the-lines.
2. Upload index.html to the repository root.
3. Under Settings > Pages, choose Deploy from a branch, main, /(root).
4. Open the published URL when GitHub finishes deployment.

All content is in index.html. Replace that file in GitHub when a new version is ready.
This is a local, browser-based educational simulation. There are no accounts, shared classroom submissions, or real news videos. The opening news bulletin is a written broadcast mockup, with an optional transcript, not recorded video. Student work is saved locally in the browser and can be exported as a .txt file.
All source testimonies and opinion columns are fictional. The map's legal check covers only exact population equality and edge contiguity.
